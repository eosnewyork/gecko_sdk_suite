/**************************************************************************//**
 * @file config.h
 * @brief defines for ogg and opus
 * @version 5.3.0
 ******************************************************************************
 * # License
 * <b>Copyright 2017 Silicon Labs, Inc. http://www.silabs.com</b>
 *******************************************************************************
 *
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 *
 ******************************************************************************/

#ifndef CONFIG_H
#define CONFIG_H

// -----------------------------------------------------------------------------
// Opus defines

#define OPUS_ARM_ASM

#define VAR_ARRAYS

#define OPUS_BUILD

// -----------------------------------------------------------------------------
// Opus and ogg defines

#define HAVE_INTTYPES_H

#define HAVE_STDINT_H

#define HAVE_STDLIB_H

#define HAVE_STRING_H

#define HAVE_LRINT

#define STDC_HEADERS 1

// -----------------------------------------------------------------------------
// Include guard

#endif // CONFIG_H
