#!/bin/bash

mkdir -p out

SOURCES=sources.libogg PROJECTNAME=libogg_iar  make -f Makefile.iar  clean library
SOURCES=sources.libogg PROJECTNAME=libogg_gcc  make -f Makefile.gcc  clean library
SOURCES=sources.libogg PROJECTNAME=libogg_keil make -f Makefile.keil clean library
SOURCES=sources.opus PROJECTNAME=libopus_iar  CFLAGS="-DHAVE_CONFIG_H --vla -Ohs" make -f Makefile.iar clean library
SOURCES=sources.opus PROJECTNAME=libopus_gcc  CFLAGS="-DHAVE_CONFIG_H -O3" make -f Makefile.gcc clean library
SOURCES=sources.opus PROJECTNAME=libopus_keil CFLAGS="-DHAVE_CONFIG_H --vla -O3 -Otime" make -f Makefile.keil clean library

rm -f ../*.a
rm -rf ../include
mkdir ../include

cp -R out/*.a ../
cp -R out/*.lib ../
cp -R libogg-1.3.2/include/* ../include
cp -R opus-1.2.1/include/* ../include
